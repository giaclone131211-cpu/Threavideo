# Threads2Video

App Android biến bài Threads + bình luận thành video dọc 9:16 cho TikTok.

- Dán bài viết và bình luận
- Gemini chọn bình luận hay, sửa teencode, rút gọn
- Gemini TTS đọc thành tiếng (30 giọng, đổi giọng luân phiên)
- Thẻ bình luận hiện theo nhịp giọng đọc, tô sáng từng từ
- Video nền từ thư viện, tự cắt giữa thành 9:16
- Xuất MP4 vào Phim/Threads2Video, chia sẻ thẳng lên TikTok

Cấu trúc: vỏ Kotlin (app/src/main/java) + giao diện và lõi xử lý bằng web (app/src/main/assets/www).
Build bằng GitHub Actions (xem build.yml), ra file APK debug cài được ngay.
