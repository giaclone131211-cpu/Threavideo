'use strict';
/* Threads2Video — lõi ứng dụng (chạy trong WebView của APK) */

const $ = id => document.getElementById(id);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const FONT = '"Noto Sans","Roboto","Segoe UI",system-ui,sans-serif';

/* ---------- lưu cài đặt ---------- */
const store = {
  get(k, d) { try { const v = localStorage.getItem('t2v_' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem('t2v_' + k, JSON.stringify(v)); } catch (e) {} }
};

const VOICES = [
  ['Charon','Thông tin, rõ'],['Kore','Chắc'],['Puck','Vui, sôi nổi'],['Zephyr','Tươi sáng'],['Fenrir','Hào hứng'],
  ['Leda','Trẻ trung'],['Orus','Chắc'],['Aoede','Nhẹ nhàng'],['Callirrhoe','Dễ chịu'],['Autonoe','Tươi sáng'],
  ['Enceladus','Thở nhẹ'],['Iapetus','Rõ'],['Umbriel','Dễ chịu'],['Algieba','Mượt'],['Despina','Mượt'],
  ['Erinome','Rõ'],['Algenib','Khàn'],['Rasalgethi','Thông tin'],['Laomedeia','Vui'],['Achernar','Mềm'],
  ['Alnilam','Chắc'],['Schedar','Đều'],['Gacrux','Chín chắn'],['Pulcherrima','Thẳng'],['Achird','Thân thiện'],
  ['Zubenelgenubi','Tự nhiên'],['Vindemiatrix','Dịu'],['Sadachbia','Sống động'],['Sadaltager','Am hiểu'],['Sulafat','Ấm']
];
const STYLES = {
  story:  ['Kể chuyện cuốn hút', 'captivating storyteller, natural human pacing, expressive with subtle dramatic emphasis'],
  tiktok: ['Hào hứng kiểu review TikTok', 'energetic and upbeat like a popular short-video creator, slightly fast pace'],
  drama:  ['Trầm, kịch tính', 'low, intense and suspenseful, slow deliberate pacing'],
  friend: ['Thân mật như bạn bè', 'warm, casual and conversational, like chatting with a close friend'],
  plain:  ['Tự nhiên (không chỉ dẫn)', '']
};
const NEON = { cyan:'#22d3ee', pink:'#f472b6', gold:'#fbbf24', violet:'#a78bfa', green:'#4ade80', none:null };

const DEF = {
  key:'', textModel:'gemini-3.8-flash', ttsModel:'gemini-3.8-flash-tts',
  narrator:'Charon', voices:['Kore','Puck','Leda'], style:'story',
  aiPick:true, topN:'8', criteria:'mix', rewrite:true,
  anim:'pop', neon:'cyan', fs:46, posY:42, hl:true, sfx:true, musicVol:12, dim:25, startAt:0, quality:'1080'
};
const cfg = Object.assign({}, DEF, store.get('cfg', {}));
const save = () => store.set('cfg', cfg);

const S = {
  v: null, vw: 0, vh: 0, vurl: null,
  music: null, segs: [], total: 0, ready: false, busy: false,
  ac: null, raf: 0, cancel: false, running: null, ttsCache: new Map(),
  exporting: false, lastUri: '', lastMime: '', lastBlobUrl: null
};

/* ---------- tiện ích UI ---------- */
let toastT;
function toast(m) {
  const t = $('toast'); t.textContent = m; t.classList.add('on');
  clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('on'), 2600);
}
function plog(m, cls) {
  const d = document.createElement('div'); if (cls) d.className = cls; d.textContent = m;
  const l = $('plog'); l.appendChild(d); l.scrollTop = l.scrollHeight;
}
const setBar = p => { $('bar').style.width = (clamp(p, 0, 1) * 100).toFixed(1) + '%'; };

let curPane = 1;
function go(n) {
  curPane = n;
  document.querySelectorAll('.pane').forEach((p, i) => p.classList.toggle('on', i + 1 === n));
  document.querySelectorAll('#nav button').forEach((b, i) => b.classList.toggle('on', i + 1 === n));
  $('p' + n).scrollIntoView(); document.querySelector('main').scrollTop = 0;
  if (n === 4) refreshStill();
}
document.querySelectorAll('[data-go]').forEach(b => b.addEventListener('click', () => go(+b.dataset.go)));
window.__back = () => {
  if (S.exporting) { toast('Đang xuất video, hãy chờ xong rồi thoát'); return false; }
  if (curPane > 1) { go(curPane - 1); return false; }
  return true;
};

/* ---------- gắn cài đặt vào ô nhập ---------- */
function fillSelects() {
  $('style').innerHTML = Object.entries(STYLES).map(([k, v]) => `<option value="${k}">${v[0]}</option>`).join('');
  $('narrator').innerHTML = VOICES.map(([n, d]) => `<option value="${n}">${n} — ${d}</option>`).join('');
}
function buildChips() {
  const box = $('chips'); box.innerHTML = '';
  VOICES.forEach(([n, d]) => {
    const c = document.createElement('div');
    c.className = 'chip' + (cfg.voices.includes(n) ? ' on' : '');
    c.innerHTML = `<span>${n} <em>${d}</em></span><span class="pl">▶</span>`;
    c.addEventListener('click', e => {
      if (e.target.classList.contains('pl')) { previewVoice(n); return; }
      const i = cfg.voices.indexOf(n);
      if (i >= 0) cfg.voices.splice(i, 1); else cfg.voices.push(n);
      c.classList.toggle('on', i < 0); save();
    });
    box.appendChild(c);
  });
}
const REFRESH_KEYS = ['dim', 'startAt', 'anim', 'neon', 'fs', 'posY', 'hl'];
function bindCfg() {
  document.querySelectorAll('[data-k]').forEach(el => {
    const k = el.dataset.k;
    if (el.type === 'checkbox') el.checked = !!cfg[k]; else el.value = cfg[k];
    const lab = $(el.id + 'V');
    const show = () => { if (lab) lab.textContent = el.value + (k === 'dim' ? '%' : ''); };
    show();
    el.addEventListener('input', () => {
      cfg[k] = el.type === 'checkbox' ? el.checked : (el.type === 'range' || el.type === 'number') ? Number(el.value) : el.value;
      show(); save();
      if (k === 'startAt') seekStart();
      if (REFRESH_KEYS.includes(k)) refreshStill();
    });
  });
}

/* ---------- phân tích bình luận ---------- */
function parseComments(raw) {
  const blocks = (raw || '').split(/\n\s*\n/).map(b => b.trim()).filter(Boolean);
  const out = [];
  blocks.forEach((b, i) => {
    const lines = b.split('\n').map(l => l.trim()).filter(Boolean);
    let user = '', likes = '', text = '';
    let m = lines[0].match(/^@([\w.\-]{2,32})\s*(?:[|·•\-]\s*([\d.,]+\s*[KkMm]?))?\s*:?$/);
    if (m && lines.length > 1) { user = '@' + m[1]; likes = (m[2] || '').trim(); text = lines.slice(1).join(' '); }
    else {
      m = lines[0].match(/^@?([\w.\-]{2,32})\s*[:：]\s*(.+)$/);
      if (m && /^@/.test(lines[0]) || (m && !/\s/.test(lines[0].split(/[:：]/)[0]) && /[._\d]/.test(m[1]))) {
        user = '@' + m[1]; text = [m[2]].concat(lines.slice(1)).join(' ');
      } else { user = '@nguoi_dung' + (i + 1); text = lines.join(' '); }
    }
    text = text.replace(/\s+/g, ' ').trim();
    if (text) out.push({ user, likes, text });
  });
  return out;
}
function updateCount() {
  const n = parseComments($('cText').value).length;
  $('cCount').textContent = n ? '· đã nhận ' + n : '';
}

/* ---------- gọi Gemini ---------- */
let onWait = null;
async function gemRaw(model, body) {
  const key = cfg.key.trim();
  if (!key) throw new Error('Chưa nhập Gemini API key (tab Giọng)');
  const url = 'https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(model) + ':generateContent';
  let last;
  for (let a = 0; a < 4; a++) {
    let r;
    try {
      r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key }, body: JSON.stringify(body) });
    } catch (e) { throw new Error('Không kết nối được tới Google. Kiểm tra mạng.'); }
    if (r.ok) return r.json();
    let msg = ''; try { msg = (await r.json()).error.message || ''; } catch (e) {}
    last = new Error('Gemini ' + r.status + (msg ? ': ' + msg.slice(0, 160) : '')); last.status = r.status; last.msg = msg;
    if ([429, 500, 503].includes(r.status) && a < 3) {
      const m = msg.match(/retry in ([\d.]+)s/i);
      const w = Math.min(40, m ? Math.ceil(+m[1]) + 1 : 6 * (a + 1));
      for (let s = w; s > 0; s--) { if (onWait) onWait(s); await sleep(1000); if (S.cancel) throw new Error('Đã dừng'); }
      continue;
    }
    throw last;
  }
  throw last;
}
async function gemText(prompt, json) {
  const models = [...new Set([cfg.textModel, 'gemini-3.8-flash', 'gemini-2.5-flash'])];
  let err;
  for (const m of models) {
    try {
      const body = { contents: [{ role: 'user', parts: [{ text: prompt }] }] };
      if (json) body.generationConfig = { responseMimeType: 'application/json' };
      const j = await gemRaw(m, body);
      const t = (j.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('');
      if (!t) throw new Error('Gemini không trả về nội dung');
      return t;
    } catch (e) { err = e; if (e.status !== 404) throw e; }
  }
  throw err;
}
function b64ToU8(b64) {
  const bin = atob(b64); const u = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  return u;
}
function pcmToBuffer(ac, u8, rate) {
  let off = 0;
  if (u8.length > 44 && u8[0] === 0x52 && u8[1] === 0x49 && u8[2] === 0x46 && u8[3] === 0x46) {
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    let p = 12; off = 44; rate = dv.getUint32(24, true) || rate;
    while (p + 8 <= u8.length) {
      const id = String.fromCharCode(u8[p], u8[p + 1], u8[p + 2], u8[p + 3]); const sz = dv.getUint32(p + 4, true);
      if (id === 'data') { off = p + 8; break; }
      p += 8 + sz;
    }
  }
  const n = Math.floor((u8.length - off) / 2);
  const dv = new DataView(u8.buffer, u8.byteOffset + off, n * 2);
  const f = new Float32Array(n);
  let i0 = -1, i1 = 0;
  for (let i = 0; i < n; i++) { const v = dv.getInt16(i * 2, true) / 32768; f[i] = v; if (Math.abs(v) > 0.012) { if (i0 < 0) i0 = i; i1 = i; } }
  if (i0 < 0) throw new Error('Âm thanh trống');
  const pad = Math.round(rate * 0.05);
  const a = Math.max(0, i0 - pad), b = Math.min(n, i1 + pad);
  const buf = ac.createBuffer(1, b - a, rate);
  buf.getChannelData(0).set(f.subarray(a, b));
  return buf;
}
const speakable = t => t.replace(/https?:\/\/\S+/g, ' ').replace(/[\p{Extended_Pictographic}\u200d\ufe0f]/gu, '').replace(/\s+/g, ' ').trim();

async function tts(text, voice) {
  const ck = [cfg.ttsModel, voice, cfg.style, text].join('|');
  if (S.ttsCache.has(ck)) return S.ttsCache.get(ck);
  const ac = getAC();
  const mk = withFmt => {
    const part = { text }; const sty = STYLES[cfg.style][1]; if (sty) part.speech_metadata = { style: sty };
    const gc = { responseModalities: ['AUDIO'], speechConfig: { voiceConfig: { voice } } };
    if (withFmt) gc.responseFormat = { audio: { mimeType: 'AUDIO_L16', sampleRate: 24000 } };
    return { contents: [{ role: 'user', parts: [part] }], generationConfig: gc };
  };
  const models = [...new Set([cfg.ttsModel, 'gemini-3.8-flash-lite-tts'])];
  let err;
  for (const m of models) {
    for (const fmt of [true, false]) {
      try {
        const j = await gemRaw(m, mk(fmt));
        const p = (j.candidates?.[0]?.content?.parts || []).find(x => x.inlineData || x.inline_data);
        const d = p && (p.inlineData || p.inline_data);
        if (!d || !d.data) throw new Error('Gemini không trả về âm thanh');
        const mime = d.mimeType || d.mime_type || '';
        const rm = mime.match(/rate=(\d+)/);
        const buf = pcmToBuffer(ac, b64ToU8(d.data), rm ? +rm[1] : 24000);
        S.ttsCache.set(ck, buf); return buf;
      } catch (e) {
        err = e;
        if (S.cancel) throw e;
        if (e.status === 400 && fmt) continue;
        if (e.status === 404 || e.status === 429) break;
        if (e.status) throw e;
        if (!fmt) break;
      }
    }
  }
  throw err;
}

/* ---------- AudioContext ---------- */
function getAC() {
  if (!S.ac) S.ac = new (window.AudioContext || window.webkitAudioContext)();
  return S.ac;
}
let pvNode = null;
async function previewVoice(name) {
  try {
    if (!cfg.key.trim()) { toast('Nhập Gemini API key trước'); return; }
    toast('Đang tạo giọng ' + name + '…');
    const ac = getAC(); await ac.resume();
    const b = await tts('Xin chào, đây là giọng đọc thử cho video của bạn. Chuyện này mà kể lên là cuốn lắm đó!', name);
    if (pvNode) { try { pvNode.stop(); } catch (e) {} }
    pvNode = ac.createBufferSource(); pvNode.buffer = b; pvNode.connect(ac.destination); pvNode.start();
  } catch (e) { toast(e.message); }
}

/* ---------- AI chọn và viết lại bình luận ---------- */
async function aiPick(post, cms) {
  const all = cfg.topN === 'all';
  const N = all ? cms.length : Math.min(+cfg.topN, cms.length);
  if (all && !cfg.rewrite) return cms;
  const crit = { mix: 'đa dạng và cuốn nhất để giữ người xem tới cuối video', funny: 'hài hước, bá đạo, dễ viral', drama: 'gây tranh cãi, drama, nhiều cảm xúc', deep: 'sâu sắc, ý nghĩa, dễ đồng cảm' }[cfg.criteria];
  const list = cms.map((c, i) => (i + 1) + '. [' + c.user + '] ' + c.text).join('\n');
  const prompt =
`Bạn là biên tập viên video TikTok tiếng Việt.
Bài viết gốc: """${post.text}"""
Danh sách bình luận:
${list}

Nhiệm vụ: chọn ${all ? 'tất cả' : 'tối đa ' + N} bình luận ${crit}, sắp xếp theo thứ tự kể chuyện hợp lý (bình luận mạnh nhất không nhất thiết đứng đầu).
${cfg.rewrite ? 'Với mỗi bình luận, viết lại cho máy đọc thành tiếng nghe tự nhiên: sửa teencode và viết tắt, bỏ emoji, rút gọn còn tối đa 230 ký tự, giữ nguyên ý và giọng điệu.' : 'Giữ nguyên nội dung từng bình luận.'}
Chỉ trả về JSON dạng [{"i": số thứ tự gốc, "t": "nội dung"}] và không thêm gì khác.`;
  const raw = await gemText(prompt, true);
  let arr;
  try { arr = JSON.parse(raw.replace(/^```json|```$/g, '').trim()); } catch (e) { throw new Error('AI trả về dữ liệu không đọc được'); }
  const out = [], seen = new Set();
  for (const it of arr) {
    const o = cms[(it.i | 0) - 1]; if (!o || seen.has(it.i)) continue; seen.add(it.i);
    const t = String(it.t || '').trim();
    out.push({ user: o.user, likes: o.likes, text: (cfg.rewrite && t) ? t.slice(0, 320) : o.text });
    if (out.length >= N) break;
  }
  if (!out.length) throw new Error('AI không chọn được bình luận nào');
  return out;
}

/* ---------- chuẩn bị: AI + giọng đọc + timeline ---------- */
async function prepare() {
  if (S.busy) return;
  S.busy = true; S.cancel = false; S.ready = false; $('plog').innerHTML = ''; setBar(0);
  $('btnPrep').disabled = true; $('btnPlay').disabled = true; $('btnExport').disabled = true;
  onWait = s => { const l = $('plog').lastChild; if (l && l.dataset.w) l.textContent = 'Google đang giới hạn tốc độ, thử lại sau ' + s + ' giây…'; else { const d = document.createElement('div'); d.dataset.w = 1; d.className = 'warn'; d.textContent = 'Google đang giới hạn tốc độ, thử lại sau ' + s + ' giây…'; $('plog').appendChild(d); } };
  try {
    const post = { type: 'post', user: ($('pUser').value.trim() || '@tacgia'), text: $('pText').value.replace(/\s+/g, ' ').trim() };
    if (!post.text) throw new Error('Chưa có nội dung bài viết (tab Nội dung)');
    if (!cfg.key.trim()) throw new Error('Chưa nhập Gemini API key (tab Giọng)');
    let cms = parseComments($('cText').value);
    plog('Đã nhận ' + cms.length + ' bình luận.');
    if (cms.length && cfg.aiPick) {
      plog('AI đang chọn và chuẩn hóa bình luận…');
      try { cms = await aiPick(post, cms); plog('AI giữ lại ' + cms.length + ' bình luận.', 'ok'); }
      catch (e) { if (S.cancel) throw e; plog('AI chưa chạy được (' + e.message + '). Dùng bình luận gốc.', 'warn'); const n = cfg.topN === 'all' ? cms.length : +cfg.topN; cms = cms.slice(0, n); }
    } else if (cms.length && cfg.topN !== 'all') cms = cms.slice(0, +cfg.topN);
    const segs = [post].concat(cms.map(c => Object.assign({ type: 'comment' }, c)));
    const vs = cfg.voices.length ? cfg.voices : [cfg.narrator];
    let ci = 0;
    for (let i = 0; i < segs.length; i++) {
      const s = segs[i];
      s.voice = i === 0 ? cfg.narrator : vs[(ci++) % vs.length];
      const sp = speakable(s.text);
      if (!sp) { s.skip = true; continue; }
      plog('Tạo giọng ' + (i + 1) + '/' + segs.length + ' (' + s.voice + ')…');
      s.buf = await tts(sp, s.voice);
      s.audioDur = s.buf.duration;
      setBar((i + 1) / segs.length);
    }
    const ok = segs.filter(s => !s.skip);
    let t = 0.3;
    ok.forEach((s, i) => { s.start = t; s.dur = s.audioDur + 0.25; s.idx = i; t = s.start + s.dur + 0.18; });
    ok.forEach(s => { s.n = ok.length; });
    S.segs = ok; S.total = t + 0.7; S.ready = true;
    plog('Xong. Video dài ' + S.total.toFixed(0) + ' giây, ' + ok.length + ' thẻ.', 'ok');
    $('btnPlay').disabled = false; $('btnExport').disabled = false;
    refreshStill();
  } catch (e) { plog(e.message, 'err'); }
  finally { S.busy = false; onWait = null; $('btnPrep').disabled = false; }
}

/* ---------- vẽ khung hình ---------- */
const mc = document.createElement('canvas').getContext('2d');
function rr(c, x, y, w, h, r) {
  r = Math.min(r, w / 2, h / 2);
  c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r);
  c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath();
}
function hueOf(s) { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 360; return h; }

function layout(seg, W, H) {
  const key = [W, H, cfg.fs, cfg.neon, seg.text, seg.user, seg.likes || '', seg.type].join('|');
  if (seg._lay && seg._lay.key === key) return seg._lay;
  const k = W / 1080, cardW = Math.round(W * 0.86), pad = Math.round(44 * k), av = Math.round(76 * k);
  const headH = av + Math.round(34 * k), gp = Math.round(50 * k);
  const words = seg.text.replace(/\s+/g, ' ').trim().split(' ');
  const maxBody = H * 0.44; let fs = cfg.fs * k, lines, lh, sp;
  for (;;) {
    mc.font = '500 ' + fs + 'px ' + FONT; sp = mc.measureText(' ').width;
    const maxW = cardW - 2 * pad; lines = []; let cur = [], w = 0;
    for (const wd of words) {
      const ww = mc.measureText(wd).width;
      if (cur.length && w + sp + ww > maxW) { lines.push(cur); cur = []; w = 0; }
      w += (cur.length ? sp : 0) + ww; cur.push({ t: wd, w: ww });
    }
    if (cur.length) lines.push(cur);
    lh = fs * 1.4;
    if (lines.length * lh <= maxBody || fs <= 24 * k) break;
    fs -= 2 * k;
  }
  const out = []; let tot = 0;
  lines.forEach((ln, li) => { let x = pad; ln.forEach(o => { const wt = o.t.length + (/[,.!?;:…]$/.test(o.t) ? 3 : 0) + 1; out.push({ t: o.t, x, y: li * lh + fs, w: o.w, wt }); x += o.w + sp; tot += wt; }); });
  let acc = 0; out.forEach(o => { o.f0 = acc / tot; acc += o.wt; o.f1 = acc / tot; });
  const cardH = pad + headH + lines.length * lh + pad * 0.7;
  const base = document.createElement('canvas'); base.width = cardW + 2 * gp; base.height = Math.round(cardH + 2 * gp);
  const b = base.getContext('2d'), col = NEON[cfg.neon];
  b.save();
  if (col) { b.shadowColor = col; b.shadowBlur = 38 * k; } else { b.shadowColor = 'rgba(0,0,0,.5)'; b.shadowBlur = 30 * k; b.shadowOffsetY = 10 * k; }
  b.fillStyle = 'rgba(255,255,255,.97)'; rr(b, gp, gp, cardW, cardH, 34 * k); b.fill(); b.restore();
  if (col) { b.lineWidth = 4 * k; b.strokeStyle = col; rr(b, gp, gp, cardW, cardH, 34 * k); b.stroke(); }
  const ax = gp + pad + av / 2, ay = gp + pad + av / 2;
  b.fillStyle = 'hsl(' + hueOf(seg.user) + ',68%,52%)'; b.beginPath(); b.arc(ax, ay, av / 2, 0, 7); b.fill();
  b.fillStyle = '#fff'; b.font = '700 ' + 36 * k + 'px ' + FONT; b.textAlign = 'center'; b.textBaseline = 'middle';
  b.fillText((seg.user.replace('@', '')[0] || '?').toUpperCase(), ax, ay + 2 * k);
  b.textAlign = 'left'; b.textBaseline = 'alphabetic';
  const nx = gp + pad + av + 22 * k;
  b.fillStyle = '#0f172a'; b.font = '700 ' + 34 * k + 'px ' + FONT; b.fillText(seg.user, nx, ay - 2 * k);
  b.fillStyle = '#64748b'; b.font = '500 ' + 27 * k + 'px ' + FONT;
  b.fillText(seg.type === 'post' ? 'Bài viết' : (seg.likes ? seg.likes + ' lượt thích' : 'Bình luận'), nx, ay + 30 * k);
  return (seg._lay = { key, base, words: out, fs, gp, pad, headH, k, lh });
}
const eoBack = x => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2); };
const eoCubic = x => 1 - Math.pow(1 - x, 3);

function drawFrame(g, W, H, t, segs, total, fixedProg) {
  const v = S.v;
  if (v && S.vw && v.readyState >= 2) {
    const sc = Math.max(W / S.vw, H / S.vh), dw = S.vw * sc, dh = S.vh * sc;
    g.drawImage(v, (W - dw) / 2, (H - dh) / 2, dw, dh);
  } else {
    const gr = g.createLinearGradient(0, 0, W, H); gr.addColorStop(0, '#0f1b3d'); gr.addColorStop(1, '#2a1250');
    g.fillStyle = gr; g.fillRect(0, 0, W, H);
  }
  g.fillStyle = 'rgba(0,0,0,' + cfg.dim / 100 + ')'; g.fillRect(0, 0, W, H);
  let seg = null;
  for (const s of segs) if (t >= s.start && t <= s.start + s.dur + 0.25) seg = s;
  const k = W / 1080;
  if (seg) {
    const L = layout(seg, W, H);
    const p = clamp((t - seg.start) / 0.32, 0, 1), q = clamp((t - (seg.start + seg.dur)) / 0.22, 0, 1);
    let sc = 1, dy = 0, al = 1;
    if (cfg.anim === 'pop') { sc = 0.8 + 0.2 * eoBack(p); al = clamp(p * 2.5, 0, 1); }
    else if (cfg.anim === 'slide') { dy = (1 - eoCubic(p)) * 140 * k; al = clamp(p * 2, 0, 1); }
    else { al = p; }
    al *= 1 - q; if (q > 0) { dy -= q * 60 * k; if (cfg.anim === 'pop') sc *= 1 - q * 0.06; }
    g.save();
    g.translate(W / 2, H * cfg.posY / 100 + dy); g.scale(sc, sc); g.globalAlpha = al;
    const bw = L.base.width, bh = L.base.height;
    g.drawImage(L.base, -bw / 2, -bh / 2);
    const ox = -bw / 2 + L.gp, oy = -bh / 2 + L.gp + L.pad + L.headH;
    g.font = '500 ' + L.fs + 'px ' + FONT; g.textBaseline = 'alphabetic';
    const prog = fixedProg != null ? fixedProg : clamp((t - seg.start - 0.05) / (seg.audioDur * 0.96), 0, 1);
    for (const w of L.words) {
      const state = !cfg.hl ? 0 : prog >= w.f1 ? 0 : prog >= w.f0 ? 1 : 2;
      if (state === 1) { g.fillStyle = '#fde047'; rr(g, ox + w.x - 7 * k, oy + w.y - L.fs * 0.92, w.w + 14 * k, L.fs * 1.28, 9 * k); g.fill(); }
      g.fillStyle = state === 2 ? '#94a3b8' : '#0f172a';
      g.fillText(w.t, ox + w.x, oy + w.y);
    }
    g.restore();
    if (seg.n > 1) {
      const label = seg.type === 'post' ? 'Bài viết' : 'Bình luận ' + seg.idx + '/' + (seg.n - 1);
      g.save(); g.globalAlpha = Math.min(1, al * 1.4);
      g.font = '700 ' + 32 * k + 'px ' + FONT; const tw = g.measureText(label).width + 56 * k;
      g.fillStyle = 'rgba(8,12,28,.72)'; rr(g, (W - tw) / 2, H * 0.085, tw, 62 * k, 31 * k); g.fill();
      g.fillStyle = NEON[cfg.neon] || '#fff'; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillText(label, W / 2, H * 0.085 + 33 * k); g.restore();
    }
  }
  if (total) { g.fillStyle = NEON[cfg.neon] || '#fff'; g.fillRect(0, H - 10 * k, W * clamp(t / total, 0, 1), 10 * k); }
}

/* ---------- ảnh tĩnh xem trước khi chỉnh giao diện ---------- */
function stillSeg() {
  const base = S.segs[0] || { type: 'post', user: $('pUser').value.trim() || '@tacgia', text: $('pText').value.trim() || 'Nội dung bài viết sẽ hiện ở đây. Chỉnh cỡ chữ, vị trí và viền thẻ để xem thử.' };
  return Object.assign({}, base, { start: 0, dur: 99, audioDur: 99, n: 1, idx: 0, _lay: null });
}
function refreshStill() {
  if (S.running) return;
  const cv = $('cv'); if (cv.width !== 540) { cv.width = 540; cv.height = 960; }
  drawFrame(cv.getContext('2d'), 540, 960, 1, [stillSeg()], 0, 0.4);
}
function seekStart() {
  if (!S.v || !S.v.duration) return;
  try { S.v.currentTime = cfg.startAt % S.v.duration; } catch (e) {}
}

/* ---------- chọn video nền / nhạc ---------- */
$('btnVid').onclick = () => $('vidIn').click();
$('vidIn').onchange = e => {
  const f = e.target.files[0]; if (!f) return;
  if (S.vurl) URL.revokeObjectURL(S.vurl);
  S.vurl = URL.createObjectURL(f);
  const v = document.createElement('video'); v.muted = true; v.loop = true; v.playsInline = true; v.preload = 'auto'; v.src = S.vurl;
  v.onloadedmetadata = () => {
    S.vw = v.videoWidth; S.vh = v.videoHeight; S.v = v;
    const r = S.vw / S.vh, need = Math.abs(r - 9 / 16) > 0.02;
    $('vInfo').textContent = f.name + ' — ' + S.vw + '×' + S.vh + ', ' + Math.round(v.duration) + ' giây. ' + (need ? 'Sẽ cắt giữa thành 9:16.' : 'Đã đúng 9:16.');
    seekStart();
  };
  v.onseeked = () => refreshStill();
  v.onloadeddata = () => refreshStill();
  v.onerror = () => toast('Không đọc được video này. Thử video khác.');
  const p = $('bgPrev'); p.src = S.vurl; p.style.display = 'block';
};
$('btnMusic').onclick = () => $('musicIn').click();
$('musicIn').onchange = async e => {
  const f = e.target.files[0]; if (!f) return;
  try {
    $('mInfo').textContent = 'Đang đọc nhạc…';
    S.music = await getAC().decodeAudioData(await f.arrayBuffer());
    $('mInfo').textContent = f.name + ' — ' + Math.round(S.music.duration) + ' giây';
  } catch (er) { S.music = null; $('mInfo').textContent = 'Không đọc được file nhạc này.'; }
};

/* ---------- phát / ghi video ---------- */
const Q = () => cfg.quality === '720' ? { w: 720, h: 1280, bps: 5e6 } : { w: 1080, h: 1920, bps: 9e6 };
function pickMime() {
  const c = ['video/mp4;codecs=avc1.640028,mp4a.40.2', 'video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'];
  if (window.MediaRecorder) for (const t of c) if (MediaRecorder.isTypeSupported(t)) return t;
  return '';
}
function sfxPop(ac, bus, at) {
  const o = ac.createOscillator(), g = ac.createGain(); o.type = 'sine';
  o.frequency.setValueAtTime(900, at); o.frequency.exponentialRampToValueAtTime(380, at + 0.09);
  g.gain.setValueAtTime(0.0001, at); g.gain.exponentialRampToValueAtTime(0.18, at + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, at + 0.15);
  o.connect(g); g.connect(bus); o.start(at); o.stop(at + 0.17);
}
async function run(record) {
  const ac = getAC(); await ac.resume();
  const W = record ? Q().w : 540, H = record ? Q().h : 960;
  const cv = $('cv'); cv.width = W; cv.height = H; const g = cv.getContext('2d');
  S.segs.forEach(s => { s._lay = null; });
  const segs = S.segs, total = S.total;
  const bus = ac.createGain(); bus.connect(ac.destination);
  let dest = null; if (record) { dest = ac.createMediaStreamDestination(); bus.connect(dest); }
  const t0 = ac.currentTime + 0.4, nodes = [];
  segs.forEach(s => { const n = ac.createBufferSource(); n.buffer = s.buf; n.connect(bus); n.start(t0 + s.start); nodes.push(n); if (cfg.sfx) sfxPop(ac, bus, t0 + s.start - 0.03); });
  if (S.music && cfg.musicVol > 0) {
    const n = ac.createBufferSource(), mg = ac.createGain(), vol = cfg.musicVol / 100;
    n.buffer = S.music; n.loop = true; mg.gain.setValueAtTime(vol, t0); mg.gain.setValueAtTime(vol, t0 + total - 1.2); mg.gain.linearRampToValueAtTime(0, t0 + total);
    n.connect(mg); mg.connect(bus); n.start(t0); nodes.push(n);
  }
  const v = S.v; if (v) { seekStart(); v.play().catch(() => {}); }
  let rec = null; const chunks = []; let mime = '';
  if (record) {
    mime = pickMime();
    const stream = cv.captureStream(30);
    dest.stream.getAudioTracks().forEach(t => stream.addTrack(t));
    rec = new MediaRecorder(stream, mime ? { mimeType: mime, videoBitsPerSecond: Q().bps, audioBitsPerSecond: 192000 } : {});
    rec.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
    rec.start(500);
  }
  S.running = { rec };
  return new Promise(resolve => {
    const finish = async cancelled => {
      cancelAnimationFrame(S.raf);
      nodes.forEach(n => { try { n.stop(); } catch (e) {} });
      if (v) v.pause();
      if (rec) await new Promise(r => { rec.onstop = r; try { rec.stop(); } catch (e) { r(); } });
      try { bus.disconnect(); } catch (e) {}
      S.running = null; setBar(0);
      if (record) { $('cv').width = 540; $('cv').height = 960; }
      refreshStill();
      resolve(cancelled || !rec ? null : new Blob(chunks, { type: (rec.mimeType || mime || 'video/webm').split(';')[0] }));
    };
    const tick = () => {
      if (S.cancel) { finish(true); return; }
      const t = ac.currentTime - t0;
      drawFrame(g, W, H, t, segs, total);
      setBar(t / total);
      if (t >= total) { finish(false); return; }
      S.raf = requestAnimationFrame(tick);
    };
    tick();
  });
}

function b64Of(blob) {
  return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1]); r.onerror = rej; r.readAsDataURL(blob); });
}
async function saveBlob(blob, name, mime) {
  if (window.Android && Android.beginSave) {
    if (!Android.beginSave(name, mime)) throw new Error('Không tạo được file trong Phim/Threads2Video');
    const CH = 1500000;
    for (let off = 0; off < blob.size; off += CH) {
      if (!Android.writeChunk(await b64Of(blob.slice(off, off + CH)))) throw new Error('Ghi file bị lỗi, kiểm tra dung lượng máy');
      setBar(off / blob.size);
    }
    return Android.endSave();
  }
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove();
  return '';
}

async function doPlay() {
  if (!S.ready || S.running) return;
  S.cancel = false; $('btnPlay').disabled = true; $('btnExport').disabled = true; $('btnCancel').style.display = 'block';
  await run(false);
  $('btnPlay').disabled = false; $('btnExport').disabled = false; $('btnCancel').style.display = 'none';
}
async function doExport() {
  if (!S.ready || S.running) return;
  if (!window.MediaRecorder) { toast('Máy không hỗ trợ ghi video'); return; }
  S.cancel = false; S.exporting = true; $('result').style.display = 'none';
  $('btnPlay').disabled = true; $('btnExport').disabled = true; $('btnPrep').disabled = true; $('btnCancel').style.display = 'block';
  plog('Đang xuất ' + Q().w + '×' + Q().h + ' theo thời gian thực. Giữ app mở, đừng khóa màn hình…');
  try {
    const blob = await run(true);
    if (!blob) { plog('Đã dừng xuất video.', 'warn'); return; }
    const mp4 = blob.type.includes('mp4'), ext = mp4 ? 'mp4' : 'webm', mime = mp4 ? 'video/mp4' : 'video/webm';
    const name = 'Threads2Video_' + new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14) + '.' + ext;
    plog('Đang lưu file (' + (blob.size / 1048576).toFixed(1) + ' MB)…');
    const uri = await saveBlob(blob, name, mime);
    S.lastUri = uri; S.lastMime = mime;
    if (S.lastBlobUrl) URL.revokeObjectURL(S.lastBlobUrl);
    S.lastBlobUrl = URL.createObjectURL(blob); $('outV').src = S.lastBlobUrl;
    $('result').style.display = 'block'; $('btnShare').style.display = uri ? 'block' : 'none';
    plog('Đã lưu ' + name + (mp4 ? '' : ' (định dạng WebM, TikTok có thể không nhận)'), mp4 ? 'ok' : 'warn');
    window.__lastExport = { size: blob.size, type: blob.type, name };
    $('result').scrollIntoView({ behavior: 'smooth' });
  } catch (e) { plog('Lỗi xuất video: ' + e.message, 'err'); }
  finally {
    S.exporting = false; setBar(0);
    $('btnPlay').disabled = false; $('btnExport').disabled = false; $('btnPrep').disabled = false; $('btnCancel').style.display = 'none';
  }
}

/* ---------- caption TikTok ---------- */
async function makeCaption() {
  try {
    if (!cfg.key.trim()) { toast('Nhập Gemini API key trước'); return; }
    const post = $('pText').value.trim(); if (!post) { toast('Chưa có nội dung bài viết'); return; }
    $('btnCap').disabled = true; $('capOut').value = 'Đang viết…';
    const used = S.segs.slice(1).map(s => '- ' + s.text).join('\n');
    const t = await gemText(
`Viết caption TikTok tiếng Việt cho video kể lại bài Threads sau.
Bài viết: """${post}"""
Bình luận trong video:
${used || '(không có)'}
Yêu cầu: 1 dòng mở đầu gây tò mò dưới 90 ký tự, 1 câu kêu gọi bình luận, rồi 6 đến 8 hashtag phù hợp xu hướng Việt Nam. Không giải thích thêm.`);
    $('capOut').value = t.trim();
  } catch (e) { $('capOut').value = ''; toast(e.message); }
  finally { $('btnCap').disabled = false; }
}
function copyCap() {
  const t = $('capOut'); t.select();
  try { document.execCommand('copy'); toast('Đã sao chép'); } catch (e) { toast('Bấm giữ để sao chép thủ công'); }
}

/* ---------- dữ liệu mẫu ---------- */
const SAMPLE = {
  user: '@zakam04',
  post: 'Tại sao người giới nấu ăn đa số là phụ nữ nhưng đầu bếp thường là nam? Nghe cứ như một câu đố nhưng mà nghĩ kỹ lại thấy đúng quá.',
  comments: `@bocau_dimsua | 13,9K
Lời khuyên cho các bạn genZ: sau khi tốt nghiệp thì đi làm vài năm rồi mới nên mở quán, đừng nhảy vào luôn.

@joe.nap | 3,1K
Nấu cho cả nhà ăn thì không ai trả lương, nấu ở nhà hàng thì có lương và có cả danh xưng bếp trưởng nữa. Khác nhau chỗ đó thôi.

@thanhhafood | 2,4K
Bạn bình luận hay quá, đọc xong tui im luôn vì không cãi được câu nào.

@mina.lee99
Đầu bếp nam thường được trả cao hơn, đó là sự thật đáng buồn của ngành này.

@khang.live | 905
Ba tui nấu ngon nhất nhà nhưng cả đời chỉ nấu mỗi dịp Tết, còn mẹ tui nấu mỗi ngày mà chưa ai khen lần nào.`
};

/* ---------- khởi động ---------- */
function init() {
  fillSelects(); buildChips(); bindCfg();
  $('cText').addEventListener('input', updateCount);
  $('btnSample').onclick = () => { $('pUser').value = SAMPLE.user; $('pText').value = SAMPLE.post; $('cText').value = SAMPLE.comments; updateCount(); S.segs = []; S.ready = false; refreshStill(); toast('Đã điền dữ liệu mẫu'); };
  $('btnClear').onclick = () => { $('pText').value = ''; $('cText').value = ''; updateCount(); S.segs = []; S.ready = false; };
  $('btnPrep').onclick = prepare;
  $('btnPlay').onclick = doPlay;
  $('btnExport').onclick = doExport;
  $('btnCancel').onclick = () => { S.cancel = true; };
  $('btnCap').onclick = makeCaption;
  $('btnCopy').onclick = copyCap;
  $('btnShare').onclick = () => { if (window.Android && S.lastUri) Android.share(S.lastUri, S.lastMime); };
  ['pText', 'pUser'].forEach(id => $(id).addEventListener('input', () => { S.ready = false; $('btnPlay').disabled = true; $('btnExport').disabled = true; S.segs = []; }));
  $('cText').addEventListener('input', () => { S.ready = false; $('btnPlay').disabled = true; $('btnExport').disabled = true; S.segs = []; });
  refreshStill();
}
init();
window.__t2v = { S, cfg, parseComments, drawFrame, prepare, run };
